import tkinter as tk
from tkinter.ttk import *
from tkinter import messagebox
import random
import time
window = tk.Tk()
window.title("Game")
list_played = []
counter = []
chance_count = []
player_one = []
player_two = []
list0 = []

def ult_change(n):
    if list_showed[n] == white:
        counter.append(1)
        list0.append(1)

        if len(counter) != 3:
            list_showed[n] = list1[n]            #for 1st and 2nd chances
            list_played.append(list1[n])
            if len(counter) == 2:
                scored()
        if len(counter) == 3:
            list_played.append(list1[n])
            counter.pop()
            counter.pop()
            if list_played[0] != list_played[1]:    #if 1st chance is not equal to 2nd
                for i in range(0, 16):              #finding first two chances and removing them
                    if list_showed[i] == list_played[0] or list_showed[i] == list_played[1]:
                        list_showed[i] = white
                list_showed[n] = list1[n]
                list_played.pop(0)
                list_played.pop(0)
            else:
                list0.pop(0)
                list0.pop(0)
                list_showed[n] = list1[n]
                list_played.pop(0)
                list_played.pop(0)                  #removing first two elements fro
        #print('list_played = ', list_played, 'counter = ', counter)
        #print('list_showed = ', list_showed)
        #print('One:', len(player_one), 'Two:', len(player_two))
        #print('Counter:', main_counter, ' one:', player_one, ' two:', player_two)
        grid_change()
        check_win()
        chance_count.append(1)

def scored():
    if list_played[0] == list_played[1]:
        for i in range(0, 50):
            if len(list0) == (2+(i*4)):
                player_one.append(1)

            if len(list0) == (4+(i*4)):
                player_two.append(1)

def btn1_clicked():
    ult_change(0)


def btn2_clicked():
    ult_change(1)


def btn3_clicked():
    ult_change(2)


def btn4_clicked():
    ult_change(3)


def btn5_clicked():
    ult_change(4)


def btn6_clicked():
    ult_change(5)


def btn7_clicked():
    ult_change(6)


def btn8_clicked():
    ult_change(7)


def btn9_clicked():
    ult_change(8)


def btn10_clicked():
    ult_change(9)


def btn11_clicked():
    ult_change(10)


def btn12_clicked():
    ult_change(11)


def btn13_clicked():
    ult_change(12)


def btn14_clicked():
    ult_change(13)


def btn15_clicked():
    ult_change(14)


def btn16_clicked():
    ult_change(15)


def check_win():
    check = 0
    for i in range(0, 16):
        if list_showed[i] != white:
            check += 1
    if check == 16:
        winner = ''
        if len(player_one) > len(player_two):
            winner = 'Player one'
        elif len(player_one) < len(player_two):
            winner = 'Player two'
        elif len(player_one) == len(player_two):
            winner = 'Draw'
        if winner == 'Draw':
            statement = 'Its a tie!'
        else:
            statement = winner+' have won!'
            messagebox.showinfo("Game Over", statement)
def help():
    instruct = 'Click on any card to reveal the picture behind it.\nA copy of each picture is there behind any other random card.\nYour aim is to find maximum pairs of pictures before your friend.'

    messagebox.showinfo("Instructions", instruct)


def grid_change():
    btn1 = tk.Button(window, width=100, height=100, image=list_showed[0], command=btn1_clicked)
    btn2 = tk.Button(window, width=100, height=100, image=list_showed[1], command=btn2_clicked)
    btn3 = tk.Button(window, width=100, height=100, image=list_showed[2], command=btn3_clicked)
    btn4 = tk.Button(window, width=100, height=100, image=list_showed[3], command=btn4_clicked)
    btn5 = tk.Button(window, width=100, height=100, image=list_showed[4], command=btn5_clicked)
    btn6 = tk.Button(window, width=100, height=100, image=list_showed[5], command=btn6_clicked)
    btn7 = tk.Button(window, width=100, height=100, image=list_showed[6], command=btn7_clicked)
    btn8 = tk.Button(window, width=100, height=100, image=list_showed[7], command=btn8_clicked)
    btn9 = tk.Button(window, width=100, height=100, image=list_showed[8], command=btn9_clicked)
    btn10 = tk.Button(window, width=100, height=100, image=list_showed[9], command=btn10_clicked)
    btn11 = tk.Button(window, width=100, height=100, image=list_showed[10], command=btn11_clicked)
    btn12 = tk.Button(window, width=100, height=100, image=list_showed[11], command=btn12_clicked)
    btn13 = tk.Button(window, width=100, height=100, image=list_showed[12], command=btn13_clicked)
    btn14 = tk.Button(window, width=100, height=100, image=list_showed[13], command=btn14_clicked)
    btn15 = tk.Button(window, width=100, height=100, image=list_showed[14], command=btn15_clicked)
    btn16 = tk.Button(window, width=100, height=100, image=list_showed[15], command=btn16_clicked)
    btn = tk.Button(window, text="Instructions", width=14, height=2, command=help)
    btn.grid(column=3, row=0)
    list_temp = [btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16]
    r = 0  # for placing on the grid
    for col in range(1, 5):
        for row in range(0, 4):
            list_temp[r].grid(column=row, row=col)
            r += 1
    color_one = "grey"
    color_two = "white"
    for i in range(0, 50):
        if len(list0) == (1+(i*4)) or len(list0) == (4+(i*4)):
            color_one = "grey"
            color_two = "white"
            if len(list_played)==2:
                if list_played[0] != list_played[1]:
                    color_one = "grey"
                    color_two = "white"
                if list_played[0] == list_played[1]:
                    color_one = "white"
                    color_two = "grey"

        if len(list0) == (3+(i*4)) or len(list0) == (2+(i*4)):
            color_one = "white"
            color_two = "grey"
            if len(list_played)==2:
                if list_played[0] != list_played[1]:
                    color_one = "white"
                    color_two = "grey"
                if list_played[0] == list_played[1]:
                    color_one = "grey"
                    color_two = "white"


    one = 'Player one: '+ str(len(player_one))
    two = 'Player two: '+ str(len(player_two))

    label1 = tk.Label(window, text=one, width=14, height=2, bg=color_one)
    label2 = tk.Label(window, text=two, width=14, height=2, bg=color_two)
    label1.grid(column=1, row=0)
    label2.grid(column=2, row=0)

pic1 = tk.PhotoImage(file='data/mango.png')
pic2 = tk.PhotoImage(file='data/banana.png')
pic3 = tk.PhotoImage(file='data/watermelon.png')
pic4 = tk.PhotoImage(file='data/pineapple.png')
pic5 = tk.PhotoImage(file='data/apple.png')
pic6 = tk.PhotoImage(file='data/strawberry.png')
pic7 = tk.PhotoImage(file='data/kiwi.png')
pic8 = tk.PhotoImage(file='data/orange.png')
white = tk.PhotoImage(file='data/white.png')

list_showed = [white,white,white,white,white,white,white,white,white,white,white,white,white,white,white,white]
list1 = [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ']
count = 0
list_image = [pic1, pic2, pic3, pic4, pic5, pic6, pic7, pic8]
for img in list_image:
    count = 0
    while count != 2:
        r = random.randrange(0, 16)
        if list1[r] == ' ':
            list1[r] = img
            count += 1
            continue
        else:
            continue

grid_change()
window.mainloop()
